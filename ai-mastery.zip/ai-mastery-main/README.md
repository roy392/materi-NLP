Hi, ini merupakan kumpulan kode dan dataset yang digunakan dalam pembelajaran AI dari dasar.

Kode bukan untuk dihafal, melainkan di pahami intuisinya secara konsep maupun logika. Teruslah belajar dan mencoba, dan jangan pernah takut untuk salah. Karena belajar tanpa bereksperimen adalah sia-sia.

Salam,<br>
Kuncahyo Setyo Nugroho
